//
//  StoneRing2Tests.m
//  StoneRing2Tests
//
//  Created by Daniel Palm on 3/10/14.
//
//

#import <XCTest/XCTest.h>

@interface StoneRing2Tests : XCTestCase

@end

@implementation StoneRing2Tests

- (void)setUp
{
    [super setUp];
    // Put setup code here. This method is called before the invocation of each test method in the class.
}

- (void)tearDown
{
    // Put teardown code here. This method is called after the invocation of each test method in the class.
    [super tearDown];
}

- (void)testExample
{
    XCTFail(@"No implementation for \"%s\"", __PRETTY_FUNCTION__);
}

@end
