//
//  main.m
//  StoneRing2
//
//  Created by Daniel Palm on 3/10/14.
//
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[])
{
    return NSApplicationMain(argc, argv);
}
