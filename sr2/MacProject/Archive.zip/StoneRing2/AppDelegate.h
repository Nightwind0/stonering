//
//  AppDelegate.h
//  StoneRing2
//
//  Created by Daniel Palm on 3/10/14.
//
//

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate>

@property (assign) IBOutlet NSWindow *window;

@end
