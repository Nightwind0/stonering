//
//  AppDelegate.m
//  StoneRing2
//
//  Created by Daniel Palm on 3/10/14.
//
//

#import "AppDelegate.h"

@implementation AppDelegate

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification
{
    // Insert code here to initialize your application
}

@end
